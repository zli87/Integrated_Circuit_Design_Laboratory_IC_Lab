#include<iostream>
#include<fstream>
#include<cstdlib>
#include<iomanip>
using namespace std;

ofstream f_mode;
ofstream f_ans;
ofstream f_data;

int CRC_cal(int CRC,int message[],int remainder[]);

int main(void)
{
	f_mode.open("mode.txt");
	f_data.open("data.txt");
	f_ans.open("ans.txt");
	srand(time(NULL));
	
	
	int mode,CRC,message[58]={0},copy[58]={0},ans[58]={0};
	int p=100;
	
	for(int i=0;i<p;i++){
		
		mode=rand()%2;
		CRC=rand()%2;
		
		f_mode<<mode<<" "<<CRC<<endl;
		for(int j=0;j<58;j++){
			message[j]=rand()%2;
			if(mode==0 && j<5)
				message[j]=0;
			copy[j]=message[j];
			f_data<<message[j];
			if(j==25)
				f_data<<" ";
		}
		f_data<<endl;
		
		int rem[5],check;
		if(mode==0){
			for(int j=0;j<58;j++){
				if(j<53){
					copy[j]=copy[j+5];
					message[j]=message[j+5];
				}else{
					copy[j]=0;
					message[j]=0;
				}
			}
		}
		
		check=CRC_cal(CRC,copy,rem);
		
		if(mode==0){
			for(int j=0;j<58;j++){
				if(j<53)
					ans[j]=message[j];
				else
					ans[j]=rem[j-53];
			}
		}else{
			for(int j=0;j<58;j++){
				if(check==0)
					ans[j]=0;
				else
					ans[j]=1;
			}
		}
		
		
		for(int j=0;j<58;j++){
			f_ans<<ans[j];
			if(j==25)
				f_ans<<" ";
		}
		f_ans<<endl;
	}

	return 0;
}

int CRC_cal(int CRC,int message[],int remainder[])
{
	int div[6];
	if(CRC==0){
		div[0]=1;
		div[1]=0;
		div[2]=1;
		div[3]=0;
		div[4]=1;
		div[5]=1;
	}else{
		div[0]=1;
		div[1]=0;
		div[2]=0;
		div[3]=1;
		div[4]=0;
		div[5]=1;
	}
	
	for(int i=0;i<53;i++){
		if(message[i]==1){
			for(int j=0;j<6;j++)
				message[i+j]=message[i+j]^div[j];
		}
	}
	
	int check=0;
	for(int i=0;i<5;i++){
		remainder[i]=message[i+53];
		if(message[i+53]==1)
			check=1;
	}
	
	return check;
}
